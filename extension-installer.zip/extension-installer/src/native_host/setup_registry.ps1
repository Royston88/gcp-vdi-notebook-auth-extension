$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ($null -eq $scriptDir -or $scriptDir -eq "") {
    $scriptDir = Get-Location
}
$manifestPath = Join-Path $scriptDir "com.google.workbench.token_helper.json"

# Validate manifest path
if (-not (Test-Path $manifestPath)) {
    Write-Error "Manifest file not found: $manifestPath"
    Exit 1
}

$chromeRegistryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.google.workbench.token_helper"
$edgeRegistryPath = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.google.workbench.token_helper"

# Register for Chrome
$chromeParent = Split-Path $chromeRegistryPath -Parent
if (-not (Test-Path $chromeParent)) {
    New-Item -Path $chromeParent -Force | Out-Null
}
New-Item -Path $chromeRegistryPath -Force | Out-Null
Set-ItemProperty -Path $chromeRegistryPath -Name "(Default)" -Value $manifestPath
Write-Host "Registered in Chrome registry: $manifestPath"

# Register for Edge
$edgeParent = Split-Path $edgeRegistryPath -Parent
if (-not (Test-Path $edgeParent)) {
    New-Item -Path $edgeParent -Force | Out-Null
}
New-Item -Path $edgeRegistryPath -Force | Out-Null
Set-ItemProperty -Path $edgeRegistryPath -Name "(Default)" -Value $manifestPath
Write-Host "Registered in Edge registry: $manifestPath"
